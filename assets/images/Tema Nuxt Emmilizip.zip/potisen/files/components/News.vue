<template>
  <section class="blog-one">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
          <div class="blog-one__single">
            <div class="blog-one__image">
              <img src="/assets/images/blog/blog-1-1.jpg" alt="">
              <a class="blog-one__more-link" href="/news-details"><i class="fa fa-link"></i>
                <!-- /.fa fa-link --></a>
            </div><!-- /.blog-one__image -->
            <div class="blog-one__content">
              <ul class="list-unstyled blog-one__meta">
                <li><a href="#">22 Oct, 2019</a></li>
              </ul><!-- /.list-unstyled -->
              <h3 class="blog-one__title">
                <a href="/news-details">Pre and post launch mobile app marke- ting pitfalls </a>
              </h3><!-- /.blog-one__title -->
              <a href="/news-details" class="blog-one__link">Read More</a><!-- /.blog-one__link -->
            </div><!-- /.blog-one__content -->
          </div><!-- /.blog-one__single -->
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
          <div class="blog-one__single">
            <div class="blog-one__image">
              <img src="/assets/images/blog/blog-1-2.jpg" alt="">
              <nuxt-link class="blog-one__more-link" to="/news-details"><i class="fa fa-link"></i>
                <!-- /.fa fa-link --></nuxt-link>
            </div><!-- /.blog-one__image -->
            <div class="blog-one__content">
              <ul class="list-unstyled blog-one__meta">
                <li><a href="#">22 Oct, 2019</a></li>
              </ul><!-- /.list-unstyled -->
              <h3 class="blog-one__title">
                <nuxt-link to="/news-details">It is all exactly as i said, but i don't like it let's unpack
                  that</nuxt-link>
              </h3><!-- /.blog-one__title -->
              <nuxt-link to="/news-details" class="blog-one__link">Read More</nuxt-link><!-- /.blog-one__link -->
            </div><!-- /.blog-one__content -->
          </div><!-- /.blog-one__single -->
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
          <div class="blog-one__single">
            <div class="blog-one__image">
              <img src="/assets/images/blog/blog-1-3.jpg" alt="">
              <nuxt-link class="blog-one__more-link" to="/news-details"><i class="fa fa-link"></i>
                <!-- /.fa fa-link --></nuxt-link>
            </div><!-- /.blog-one__image -->
            <div class="blog-one__content">
              <ul class="list-unstyled blog-one__meta">
                <li><a href="#">22 Oct, 2019</a></li>
              </ul><!-- /.list-unstyled -->
              <h3 class="blog-one__title">
                <nuxt-link to="/news-details">I just wanted to give you a heads-up, this you feel you
                  would</nuxt-link>
              </h3><!-- /.blog-one__title -->
              <nuxt-link to="/news-details" class="blog-one__link">Read More</nuxt-link><!-- /.blog-one__link -->
            </div><!-- /.blog-one__content -->
          </div><!-- /.blog-one__single -->
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
          <div class="blog-one__single">
            <div class="blog-one__image">
              <img src="/assets/images/blog/blog-1-4.jpg" alt="">
              <nuxt-link class="blog-one__more-link" to="/news-details"><i class="fa fa-link"></i>
                <!-- /.fa fa-link --></nuxt-link>
            </div><!-- /.blog-one__image -->
            <div class="blog-one__content">
              <ul class="list-unstyled blog-one__meta">
                <li><a href="#">22 Oct, 2019</a></li>
              </ul><!-- /.list-unstyled -->
              <h3 class="blog-one__title">
                <nuxt-link to="/news-details">A loss a day will keep you focus run it up the flagpole</nuxt-link>
              </h3><!-- /.blog-one__title -->
              <nuxt-link to="/news-details" class="blog-one__link">Read More</nuxt-link><!-- /.blog-one__link -->
            </div><!-- /.blog-one__content -->
          </div><!-- /.blog-one__single -->
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
          <div class="blog-one__single">
            <div class="blog-one__image">
              <img src="/assets/images/blog/blog-1-5.jpg" alt="">
              <a class="blog-one__more-link" to="/news-details"><i class="fa fa-link"></i>
                <!-- /.fa fa-link --></a>
            </div><!-- /.blog-one__image -->
            <div class="blog-one__content">
              <ul class="list-unstyled blog-one__meta">
                <li><a href="#">22 Oct, 2019</a></li>
              </ul><!-- /.list-unstyled -->
              <h3 class="blog-one__title">
                <nuxt-link to="/news-details">We've got to manage that low hanging fruit here to wash
                </nuxt-link>
              </h3><!-- /.blog-one__title -->
              <nuxt-link to="/news-details" class="blog-one__link">Read More</nuxt-link><!-- /.blog-one__link -->
            </div><!-- /.blog-one__content -->
          </div><!-- /.blog-one__single -->
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
          <div class="blog-one__single">
            <div class="blog-one__image">
              <img src="/assets/images/blog/blog-1-6.jpg" alt="">
              <nuxt-link class="blog-one__more-link" to="/news-details"><i class="fa fa-link"></i>
                <!-- /.fa fa-link --></nuxt-link>
            </div><!-- /.blog-one__image -->
            <div class="blog-one__content">
              <ul class="list-unstyled blog-one__meta">
                <li><a href="#">22 Oct, 2019</a></li>
              </ul><!-- /.list-unstyled -->
              <h3 class="blog-one__title">
                <nuxt-link to="/news-details">Paddle on both sides cross functional teams enable out</nuxt-link>
              </h3><!-- /.blog-one__title -->
              <nuxt-link to="/news-details" class="blog-one__link">Read More</nuxt-link><!-- /.blog-one__link -->
            </div><!-- /.blog-one__content -->
          </div><!-- /.blog-one__single -->
        </div><!-- /.col-lg-4 -->
      </div><!-- /.row -->
      <div class="post-pagination">
        <a href="#"><i class="fa fa-angle-double-left"></i><!-- /.fa fa-angle-double-left --></a>
        <a class="active" href="#">1</a>
        <a href="#">2</a>
        <a href="#">3</a>
        <a href="#">4</a>
        <a href="#"><i class="fa fa-angle-double-right"></i><!-- /.fa fa-angle-double-left --></a>
      </div>
    </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "News"
    }
</script>

<style scoped>

</style>
