<template>
  <section class="blog-details">
    <div class="container">
      <div class="row">
        <div class="col-lg-8">
          <div class="blog-one__single">
            <div class="blog-one__image">
              <img src="/assets/images/blog/blog-d-1-1.jpg" alt="">
            </div><!-- /.blog-one__image -->
            <div class="blog-one__content">
              <ul class="list-unstyled blog-one__meta">
                <li><a href="#">By Admin</a></li>
                <li><a href="#">22 Oct, 2019</a></li>
                <li><a href="#">2 Comments</a></li>
              </ul><!-- /.list-unstyled -->
              <h3 class="blog-one__title">The people who don't just support <br> progressive change</h3><!-- /.blog-one__title -->
              <p class="blog-one__text">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some injected or words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. </p>
              <!-- /.blog-one__text -->
              <p class="blog-one__text">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting.</p><!-- /.blog-one__text -->
              <p class="blog-one__text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into unchanged. Lorem Ipsum passages publishing.</p><!-- /.blog-one__text -->
              <div class="share-block">
                <div class="left-block">
                  <p>Tags: <a href="#">Politics</a> <a href="#">Attorny</a></p>
                </div><!-- /.left-block -->
                <div class="social-block">
                  <a class="fa fa-twitter" href="#"></a>
                  <a class="fa fa-facebook-square" href="#"></a>
                  <a class="fa fa-instagram" href="#"></a>
                  <a class="fa fa-pinterest-p" href="#"></a>
                </div><!-- /.social-block -->
              </div><!-- /.share-block -->
            </div><!-- /.blog-one__content -->
          </div><!-- /.blog-one__single -->
          <div class="blog-details__author">
            <div class="blog-details__author-image">
              <img src="/assets/images/blog/author-1-1.jpg" alt="Awesome Image">
            </div><!-- /.blog-details__image -->
            <div class="blog-details__author-content">
              <h3>Christine Eve</h3>
              <p>It has survived not only five centuries, but also the leap into electronic typesetting, remaining unchanged. It was popularised in the sheets containing.</p>
            </div><!-- /.blog-details__content -->
          </div><!-- /.blog-details__author -->
          <h2 class="blog-details__content-title">2 Comments</h2><!-- /.blog-details__content-title -->
          <div class="comment-one">
            <div class="comment-one__single">
              <div class="comment-one__image">
                <div class="inner-block">
                  <img src="/assets/images/blog/comment-1-1.jpg" alt="Awesome Image">
                </div><!-- /.inner-block -->
              </div><!-- /.comment-one__image -->
              <div class="comment-one__content">
                <div class="comment-one__content-top">
                  <div class="comment-one__top-left">
                    <h3 class="comment-one__author">Laquanda Bachmeier</h3>
                    <!-- /.comment-one__author -->
                    <p class="comment-one__date">20 April, 2019 <span class="comment-one__date-sep">.</span> 4:00 pm</p>
                    <!-- /.comment-one__date -->
                    <p class="comment-one__text">Lorem Ipsum is simply dummy text of the rinting and
                      typesetting been the industry standard dummy text ever sincer condimentum purus.
                      In non ex at ligula fringilla lobortis et not the aliquet.</p>
                    <!-- /.comment-one__text -->
                  </div><!-- /.comment-one__top-left -->
                  <div class="comment-one__top-right">
                    <a href="#" class="thm-btn comment-one__reply">Reply</a>
                  </div><!-- /.comment-one__top-right -->
                </div><!-- /.comment-one__content-top -->
              </div><!-- /.comment-one__content -->
            </div><!-- /.comment-one__single -->
            <div class="comment-one__single">
              <div class="comment-one__image">
                <div class="inner-block">
                  <img src="/assets/images/blog/comment-1-2.jpg" alt="Awesome Image">
                </div><!-- /.inner-block -->
              </div><!-- /.comment-one__image -->
              <div class="comment-one__content">
                <div class="comment-one__content-top">
                  <div class="comment-one__top-left">
                    <h3 class="comment-one__author">Vicente Elmore</h3><!-- /.comment-one__author -->
                    <p class="comment-one__date">20 April, 2019 <span class="comment-one__date-sep">.</span> 4:00 pm</p>
                    <!-- /.comment-one__date -->
                    <p class="comment-one__text">Lorem Ipsum is simply dummy text of the rinting and
                      typesetting been the industry standard dummy text ever sincer condimentum purus.
                      In non ex at ligula fringilla lobortis et not the aliquet.</p>
                    <!-- /.comment-one__text -->
                  </div><!-- /.comment-one__top-left -->
                  <div class="comment-one__top-right">
                    <a href="#" class="thm-btn comment-one__reply">Reply</a>
                  </div><!-- /.comment-one__top-right -->
                </div><!-- /.comment-one__content-top -->
              </div><!-- /.comment-one__content -->
            </div><!-- /.comment-one__single -->
          </div><!-- /.comment-one -->
          <h2 class="blog-details__content-title">Leave a Comment</h2><!-- /.blog-details__content-title -->
          <form action="#" class="reply-form">
            <div class="row">
              <div class="col-lg-6">
                <input type="text" placeholder="Your name" class="reply-form__field">
              </div><!-- /.col-lg-6 -->
              <div class="col-lg-6">
                <input type="text" placeholder="Enter email" class="reply-form__field">
              </div><!-- /.col-lg-6 -->
              <div class="col-lg-12">
                <textarea placeholder="Write message" class="reply-form__field"></textarea>
                <button class="reply-form__btn thm-btn" type="submit">Submit Comment</button>
              </div><!-- /.col-lg-12 -->
            </div><!-- /.row -->
          </form><!-- /.reply-form -->
        </div><!-- /.col-lg-8 -->
        <div class="col-lg-4">
          <div class="sidebar">
            <div class="sidebar__single sidebar__search">
              <h3 class="sidebar__title">Search</h3><!-- /.sidebar__title -->
              <form action="#" class="sidebar__search-form">
                <input type="text" name="search" placeholder="Search here...">
                <button type="submit"><i class="fa fa-search"></i></button>
              </form>
            </div><!-- /.sidebar__single -->
            <div class="sidebar__single sidebar__post">
              <h3 class="sidebar__title">Latest Posts</h3><!-- /.sidebar__title -->
              <div class="sidebar__post-wrap">
                <div class="sidebar__post__single">
                  <div class="sidebar__post-image">
                    <div class="inner-block"><img src="/assets/images/blog/lp-1-1.jpg" alt="Awesome Image"></div>
                    <!-- /.inner-block -->
                  </div><!-- /.sidebar__post-image -->
                  <div class="sidebar__post-content">
                    <h4 class="sidebar__post-title"><a href="#">The people who don't just support...</a></h4>
                    <!-- /.sidebar__post-title -->
                  </div><!-- /.sidebar__post-content -->
                </div><!-- /.sidebar__post__single -->
                <div class="sidebar__post__single">
                  <div class="sidebar__post-image">
                    <div class="inner-block"><img src="/assets/images/blog/lp-1-2.jpg" alt="Awesome Image"></div>
                    <!-- /.inner-block -->
                  </div><!-- /.sidebar__post-image -->
                  <div class="sidebar__post-content">
                    <h4 class="sidebar__post-title"><a href="#">The people who don't just support...</a></h4>
                    <!-- /.sidebar__post-title -->
                  </div><!-- /.sidebar__post-content -->
                </div><!-- /.sidebar__post__single -->
                <div class="sidebar__post__single">
                  <div class="sidebar__post-image">
                    <div class="inner-block"><img src="/assets/images/blog/lp-1-3.jpg" alt="Awesome Image"></div>
                    <!-- /.inner-block -->
                  </div><!-- /.sidebar__post-image -->
                  <div class="sidebar__post-content">
                    <h4 class="sidebar__post-title"><a href="#">The people who don't just support...</a></h4>
                    <!-- /.sidebar__post-title -->
                  </div><!-- /.sidebar__post-content -->
                </div><!-- /.sidebar__post__single -->
              </div><!-- /.sidebar__post-wrap -->
            </div><!-- /.sidebar__single -->
            <div class="sidebar__single sidebar__category">
              <h3 class="sidebar__title">Categories</h3><!-- /.sidebar__title -->
              <ul class="sidebar__category-list">
                <li class="sidebar__category-list-item"><a href="#">Campaigns</a></li>
                <li class="sidebar__category-list-item"><a href="#">Politics</a></li>
                <li class="sidebar__category-list-item"><a href="#">Healthcare</a></li>
                <li class="sidebar__category-list-item"><a href="#">Economy</a></li>
                <li class="sidebar__category-list-item"><a href="#">Education</a></li>
              </ul><!-- /.sidebar__category-list -->
            </div><!-- /.sidebar__single -->
            <div class="sidebar__single sidebar__tags">
              <h3 class="sidebar__title">Tags</h3><!-- /.sidebar__title -->
              <ul class="sidebar__tags-list">
                <li class="sidebar__tags-list-item"><a href="#">Politics</a></li>
                <li class="sidebar__tags-list-item"><a href="#">Attorny</a></li>
                <li class="sidebar__tags-list-item"><a href="#">Law</a></li>
                <li class="sidebar__tags-list-item"><a href="#">Donations</a></li>
                <li class="sidebar__tags-list-item"><a href="#">Campaigns</a></li>
                <li class="sidebar__tags-list-item"><a href="#">Vote</a></li>
                <li class="sidebar__tags-list-item"><a href="#">Politicians</a></li>
              </ul><!-- /.sidebar__category-list -->
            </div><!-- /.sidebar__single -->
          </div><!-- /.sidebar -->
        </div><!-- /.col-lg-4 -->
      </div><!-- /.row -->
    </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "NewsDetails"
    }
</script>

<style scoped>

</style>
