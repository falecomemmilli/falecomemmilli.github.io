<template>
  <section class="event-one">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="event-one__single">
            <div class="event-one__image">
              <div class="event-one__image-inner">
                <img src="/assets/images/event/event-2-1.jpg" alt="">
              </div><!-- /.event-one__image-inner -->
            </div><!-- /.event-one__image -->
            <div class="event-one__content">
              <p class="event-one__date">20 Oct, 2019</p>
              <h3 class="event-one__title"><nuxt-link to="/event-details">Let’s meet your candidate in america</nuxt-link></h3><!-- /.event-one__title -->
            </div><!-- /.event-one__content -->
          </div><!-- /.event-one__single -->
        </div><!-- /.col-lg-6 -->
        <div class="col-lg-6">
          <div class="event-one__single">
            <div class="event-one__image">
              <div class="event-one__image-inner">
                <img src="/assets/images/event/event-2-2.jpg" alt="">
              </div><!-- /.event-one__image-inner -->
            </div><!-- /.event-one__image -->
            <div class="event-one__content">
              <p class="event-one__date">20 Oct, 2019</p>
              <h3 class="event-one__title"><nuxt-link to="/event-details">Let’s meet your candidate in america</nuxt-link></h3><!-- /.event-one__title -->
            </div><!-- /.event-one__content -->
          </div><!-- /.event-one__single -->
        </div><!-- /.col-lg-6 -->
        <div class="col-lg-6">
          <div class="event-one__single">
            <div class="event-one__image">
              <div class="event-one__image-inner">
                <img src="/assets/images/event/event-2-3.jpg" alt="">
              </div><!-- /.event-one__image-inner -->
            </div><!-- /.event-one__image -->
            <div class="event-one__content">
              <p class="event-one__date">20 Oct, 2019</p>
              <h3 class="event-one__title"><nuxt-link to="/event-details">Let’s meet your candidate in america</nuxt-link></h3><!-- /.event-one__title -->
            </div><!-- /.event-one__content -->
          </div><!-- /.event-one__single -->
        </div><!-- /.col-lg-6 -->
        <div class="col-lg-6">
          <div class="event-one__single">
            <div class="event-one__image">
              <div class="event-one__image-inner">
                <img src="/assets/images/event/event-2-4.jpg" alt="">
              </div><!-- /.event-one__image-inner -->
            </div><!-- /.event-one__image -->
            <div class="event-one__content">
              <p class="event-one__date">20 Oct, 2019</p>
              <h3 class="event-one__title"><nuxt-link to="/event-details">Let’s meet your candidate in america</nuxt-link></h3><!-- /.event-one__title -->
            </div><!-- /.event-one__content -->
          </div><!-- /.event-one__single -->
        </div><!-- /.col-lg-6 -->
        <div class="col-lg-6">
          <div class="event-one__single">
            <div class="event-one__image">
              <div class="event-one__image-inner">
                <img src="/assets/images/event/event-2-5.jpg" alt="">
              </div><!-- /.event-one__image-inner -->
            </div><!-- /.event-one__image -->
            <div class="event-one__content">
              <p class="event-one__date">20 Oct, 2019</p>
              <h3 class="event-one__title"><nuxt-link to="/event-details">Let’s meet your candidate in america</nuxt-link></h3><!-- /.event-one__title -->
            </div><!-- /.event-one__content -->
          </div><!-- /.event-one__single -->
        </div><!-- /.col-lg-6 -->
        <div class="col-lg-6">
          <div class="event-one__single">
            <div class="event-one__image">
              <div class="event-one__image-inner">
                <img src="/assets/images/event/event-2-6.jpg" alt="">
              </div><!-- /.event-one__image-inner -->
            </div><!-- /.event-one__image -->
            <div class="event-one__content">
              <p class="event-one__date">20 Oct, 2019</p>
              <h3 class="event-one__title"><nuxt-link to="/event-details">Let’s meet your candidate in america</nuxt-link></h3><!-- /.event-one__title -->
            </div><!-- /.event-one__content -->
          </div><!-- /.event-one__single -->
        </div><!-- /.col-lg-6 -->
      </div><!-- /.row -->
      <div class="post-pagination">
        <a href="#"><i class="fa fa-angle-double-left"></i></a>
        <a href="#">01</a>
        <a href="#">..</a>
        <a href="#">04</a>
        <a href="#"><i class="fa fa-angle-double-right"></i></a>
      </div><!-- /.post-pagination -->
    </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "Events"
    }
</script>

<style scoped>

</style>
