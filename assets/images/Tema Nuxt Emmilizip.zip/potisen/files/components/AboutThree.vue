<template>
  <section class="about-three thm-gray-bg">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="about-three__image">
            <img src="/assets/images/resources/mission-vision.jpg" alt="Awesome Image" />
          </div><!-- /.about-three__image -->
        </div><!-- /.col-lg-6 -->
        <div class="col-lg-6">
          <div class="about-three__content">
            <div class="block-title text-left">
              <img src="/assets/images/resources/sec-title-star.png" alt="Awesome Image" class="wow rotateIn" data-wow-duration="1500ms">
              <p class="block-title__tag-line">About Potisen</p>
              <h2 class="block-title__title">Mission and Vision</h2><!-- /.block-title__title -->
            </div><!-- /.block-title -->
            <div class="about-three__box-wrap">
              <div class="about-three__box">
                <i class="potisen-icon-bid"></i>
                <h4 class="about-three__box-title">Civil Rights <br> Attorney</h4><!-- /.about-three__box-title -->
              </div><!-- /.about-three__box -->
              <div class="about-three__box">
                <i class="potisen-icon-work"></i>
                <h4 class="about-three__box-title">Majored in <br> Political</h4><!-- /.about-three__box-title -->
              </div><!-- /.about-three__box -->
              <div class="about-three__box">
                <i class="potisen-icon-politics"></i>
                <h4 class="about-three__box-title">Political <br> Solutions</h4><!-- /.about-three__box-title -->
              </div><!-- /.about-three__box -->
            </div><!-- /.about-three__box-wrap -->
            <p class="about-three__text">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p><!-- /.about-three__text -->
            <a href="#" class="thm-btn about-three__btn">Learn More</a>
          </div><!-- /.about-three__content -->
        </div><!-- /.col-lg-6 -->
      </div><!-- /.row -->
    </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "AboutThree"
    }
</script>

<style scoped>

</style>
