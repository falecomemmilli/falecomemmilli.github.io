<template>
  <section class="blog-one blog-one__home-one">
    <div class="container">
      <div class="block-title text-center">
        <img src="/assets/images/resources/sec-title-star.png" alt="Awesome Image" class="wow rotateIn" data-wow-duration="1500ms">
        <p class="block-title__tag-line">Potisen Updates</p>
        <h2 class="block-title__title">From Campaign</h2><!-- /.block-title__title -->
      </div><!-- /.block-title -->
      <div class="row">
        <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
          <div class="blog-one__single">
            <div class="blog-one__image">
              <img src="/assets/images/blog/blog-1-1.jpg" alt="">
              <nuxt-link class="blog-one__more-link" to="/blog-details"><i class="fa fa-link"></i>
                <!-- /.fa fa-link --></nuxt-link>
            </div><!-- /.blog-one__image -->
            <div class="blog-one__content">
              <ul class="list-unstyled blog-one__meta">
                <li><a href="#">22 Oct, 2019</a></li>
              </ul><!-- /.list-unstyled -->
              <h3 class="blog-one__title">
                <nuxt-link to="/blog-details">Pre and post launch mobile app marke- ting pitfalls </nuxt-link>
              </h3><!-- /.blog-one__title -->
              <nuxt-link to="/blog-details" class="blog-one__link">Read More</nuxt-link><!-- /.blog-one__link -->
            </div><!-- /.blog-one__content -->
          </div><!-- /.blog-one__single -->
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
          <div class="blog-one__single">
            <div class="blog-one__image">
              <img src="/assets/images/blog/blog-1-2.jpg" alt="">
              <nuxt-link class="blog-one__more-link" to="/blog-details"><i class="fa fa-link"></i>
                <!-- /.fa fa-link --></nuxt-link>
            </div><!-- /.blog-one__image -->
            <div class="blog-one__content">
              <ul class="list-unstyled blog-one__meta">
                <li><a href="#">22 Oct, 2019</a></li>
              </ul><!-- /.list-unstyled -->
              <h3 class="blog-one__title">
                <nuxt-link to="/blog-details">It is all exactly as i said, but i don't like it let's unpack
                  that</nuxt-link>
              </h3><!-- /.blog-one__title -->
              <nuxt-link to="/blog-details" class="blog-one__link">Read More</nuxt-link><!-- /.blog-one__link -->
            </div><!-- /.blog-one__content -->
          </div><!-- /.blog-one__single -->
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
          <div class="blog-one__single">
            <div class="blog-one__image">
              <img src="/assets/images/blog/blog-1-3.jpg" alt="">
              <nuxt-link class="blog-one__more-link" to="/blog-details"><i class="fa fa-link"></i>
                <!-- /.fa fa-link --></nuxt-link>
            </div><!-- /.blog-one__image -->
            <div class="blog-one__content">
              <ul class="list-unstyled blog-one__meta">
                <li><a href="#">22 Oct, 2019</a></li>
              </ul><!-- /.list-unstyled -->
              <h3 class="blog-one__title">
                <nuxt-link to="/blog-details">I just wanted to give you a heads-up, this you feel you
                  would</nuxt-link>
              </h3><!-- /.blog-one__title -->
              <nuxt-link to="/blog-details" class="blog-one__link">Read More</nuxt-link><!-- /.blog-one__link -->
            </div><!-- /.blog-one__content -->
          </div><!-- /.blog-one__single -->
        </div><!-- /.col-lg-4 -->
      </div><!-- /.row -->
    </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "BlogOne"
    }
</script>

<style scoped>

</style>
