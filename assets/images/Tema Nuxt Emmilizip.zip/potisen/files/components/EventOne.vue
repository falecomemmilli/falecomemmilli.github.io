<template>
  <section class="event-one thm-gray-bg event-one__home-one">
    <div class="container">
      <div class="block-title text-center">
        <img src="/assets/images/resources/sec-title-star.png" alt="Awesome Image" class="wow rotateIn" data-wow-duration="1500ms">
        <p class="block-title__tag-line">Join Campaigns</p>
        <h2 class="block-title__title">Upcoming Events</h2><!-- /.block-title__title -->
      </div><!-- /.block-title -->
      <div class="row">
        <div class="col-xl-4">
          <div class="event-one__single">
            <div class="event-one__image">
              <div class="event-one__image-inner">
                <img src="/assets/images/event/event-1-1.jpg" alt="">
              </div><!-- /.event-one__image-inner -->
            </div><!-- /.event-one__image -->
            <div class="event-one__content">
              <p class="event-one__date">20 Oct, 2019</p>
              <h3 class="event-one__title"><nuxt-link to="/event-details">Let’s meet your candidate in america</nuxt-link></h3><!-- /.event-one__title -->
            </div><!-- /.event-one__content -->
          </div><!-- /.event-one__single -->
        </div><!-- /.col-lg-6 -->
        <div class="col-xl-4">
          <div class="event-one__single">
            <div class="event-one__image">
              <div class="event-one__image-inner">
                <img src="/assets/images/event/event-1-2.jpg" alt="">
              </div><!-- /.event-one__image-inner -->
            </div><!-- /.event-one__image -->
            <div class="event-one__content">
              <p class="event-one__date">20 Oct, 2019</p>
              <h3 class="event-one__title"><nuxt-link to="/event-details">Let’s meet your candidate in america</nuxt-link></h3><!-- /.event-one__title -->
            </div><!-- /.event-one__content -->
          </div><!-- /.event-one__single -->
        </div><!-- /.col-lg-6 -->
        <div class="col-xl-4">
          <div class="event-one__single">
            <div class="event-one__image">
              <div class="event-one__image-inner">
                <img src="/assets/images/event/event-1-3.jpg" alt="">
              </div><!-- /.event-one__image-inner -->
            </div><!-- /.event-one__image -->
            <div class="event-one__content">
              <p class="event-one__date">20 Oct, 2019</p>
              <h3 class="event-one__title"><nuxt-link to="/event-details">Let’s meet your candidate in america</nuxt-link></h3><!-- /.event-one__title -->
            </div><!-- /.event-one__content -->
          </div><!-- /.event-one__single -->
        </div><!-- /.col-lg-6 -->
      </div><!-- /.row -->
    </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "EventOne"
    }
</script>

<style scoped>

</style>
