<template>
  <section class="cta-one">
    <div class="container">
      <h3 class="cta-one__title">Let’s make a difference! Donate our campaign.</h3>
      <div class="cta-one__button-block">
        <a href="#" class="thm-btn cta-one__btn">Discover More</a>
      </div><!-- /.cta-one__button-block -->
    </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "CallToActionOne"
    }
</script>

<style scoped>

</style>
