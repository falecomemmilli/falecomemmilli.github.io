<template>
  <section class="campaing-two">
    <div class="container">
      <div class="block-title text-center">
        <img src="/assets/images/resources/sec-title-star.png" alt="Awesome Image" class="wow rotateIn" data-wow-duration="1500ms">
        <p class="block-title__tag-line">Make an Impact</p>
        <h2 class="block-title__title">We're here to Change <br> the Country</h2><!-- /.block-title__title -->
      </div><!-- /.block-title -->
      <div class="row">
        <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="000ms" data-wow-duration="1500ms">
          <div class="campaing-two__single text-center">
            <i class="potisen-icon-speaker"></i>
            <h3 class="campaing-two__title"><a href="#">Get Involved</a></h3><!-- /.campaing-two__title -->
            <p class="campaing-two__text">There are many vari nions of passages of available, but the have suffered.</p><!-- /.campaing-two__text -->
            <a href="#" class="campaing-two__link"><i class="potisen-icon-right-arrow"></i></a>
          </div><!-- /.campaing-two__single -->
        </div><!-- /.col-lg-3 -->
        <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="100ms" data-wow-duration="1500ms">
          <div class="campaing-two__single text-center">
            <i class="potisen-icon-washington"></i>
            <h3 class="campaing-two__title"><a href="#">Democracy</a></h3><!-- /.campaing-two__title -->
            <p class="campaing-two__text">There are many vari nions of passages of available, but the have suffered.</p><!-- /.campaing-two__text -->
            <a href="#" class="campaing-two__link"><i class="potisen-icon-right-arrow"></i></a>
          </div><!-- /.campaing-two__single -->
        </div><!-- /.col-lg-3 -->
        <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1500ms">
          <div class="campaing-two__single text-center">
            <i class="potisen-icon-good"></i>
            <h3 class="campaing-two__title"><a href="#">Civil Rights</a></h3><!-- /.campaing-two__title -->
            <p class="campaing-two__text">There are many vari nions of passages of available, but the have suffered.</p><!-- /.campaing-two__text -->
            <a href="#" class="campaing-two__link"><i class="potisen-icon-right-arrow"></i></a>
          </div><!-- /.campaing-two__single -->
        </div><!-- /.col-lg-3 -->
        <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
          <div class="campaing-two__single text-center">
            <i class="potisen-icon-vote"></i>
            <h3 class="campaing-two__title"><a href="#">Enthusiasm</a></h3><!-- /.campaing-two__title -->
            <p class="campaing-two__text">There are many vari nions of passages of available, but the have suffered.</p><!-- /.campaing-two__text -->
            <a href="#" class="campaing-two__link"><i class="potisen-icon-right-arrow"></i></a>
          </div><!-- /.campaing-two__single -->
        </div><!-- /.col-lg-3 -->
      </div><!-- /.row -->
    </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "CampaignTwo"
    }
</script>

<style scoped>

</style>
