<template>
  <section class="cta-three">
    <div class="container">
      <div class="row justify-content-between">
        <div class="col-lg-6">
          <div class="cta-three__content">
            <div class="block-title text-left">
              <img src="/assets/images/resources/sec-title-star.png" alt="Awesome Image" class="wow rotateIn" data-wow-duration="1500ms">
              <p class="block-title__tag-line">Take Actions</p>
              <h2 class="block-title__title">Absolutely New <br> Approach to Politics</h2><!-- /.block-title__title -->
            </div><!-- /.block-title -->
            <p class="cta-three__text">Aenean tincidunt id lorem ipsum is simply free text available now mauris id auctor. Donec at ligula lacus. Nulla dignissim quis neque interdum. There are many variations of passages of available but the majority have suffered alteration in lipsum is simply free.</p><!-- /.cta-three__text -->
            <a href="#" class="thm-btn cta-three__btn">Learn More</a>
          </div><!-- /.cta-three__content -->
        </div><!-- /.col-lg-6 -->
        <div class="col-lg-5">
          <div class="cta-three__box">
            <i class="potisen-icon-bid"></i>
            <h3 class="cta-three__box-title">Human rights are important</h3><!-- /.cta-three__box-title -->
            <p class="cta-three__box-text">There are many variations of passages of available but the majority have suffered alter randomised words.</p><!-- /.cta-three__box-text -->
          </div><!-- /.cta-three__box -->
          <div class="cta-three__box">
            <i class="potisen-icon-bid"></i>
            <h3 class="cta-three__box-title">Women’s leadership actions</h3><!-- /.cta-three__box-title -->
            <p class="cta-three__box-text">There are many variations of passages of available but the majority have suffered alter randomised words.</p><!-- /.cta-three__box-text -->
          </div><!-- /.cta-three__box -->
        </div><!-- /.col-lg-5 -->
      </div><!-- /.row justify-content-between -->
    </div><!-- /.container -->
    <div class="cta-three__bottom">
      <div class="container">
        <div class="inner-container thm-base-bg-2 text-center wow fadeInUp" data-wow-duration="1500ms">
          <img src="/assets/images/resources/decor-star-1-2.png" class="cta-three__bottom-star-1" alt="Awesome Image" />
          <h3 class="cta-three__bottom-title">Thank you for choosing us as your new country president</h3><!-- /.cta-three__bottom-title -->
          <img src="/assets/images/resources/decor-star-1-2.png" class="cta-three__bottom-star-2" alt="Awesome Image" />
        </div><!-- /.inner-container -->
      </div><!-- /.container -->
    </div><!-- /.cta-three__bottom -->
  </section>
</template>

<script>
    export default {
        name: "CallToActionThree"
    }
</script>

<style scoped>

</style>
