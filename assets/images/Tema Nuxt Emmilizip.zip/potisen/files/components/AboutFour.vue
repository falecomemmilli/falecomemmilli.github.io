<template>
  <section class="about-four">
    <div class="container">
      <div class="row">
        <div class="col-xl-4 col-lg-12">
          <div class="about-four__content">
            <div class="block-title text-left">
              <p class="block-title__tag-line">Potisen Politics</p>
              <h2 class="block-title__title">We can build <br> better future <br> together</h2>
              <!-- /.block-title__title -->
            </div><!-- /.block-title -->
            <ul class="list-unstyled about-four__list">
              <li>
                <img src="assets/images/resources/menu-active-star.png" alt="Awesome Image"/>
                Lorem ipsum is simply available.
              </li>
              <li>
                <img src="assets/images/resources/menu-active-star.png" alt="Awesome Image"/>
                The majority have suffered alteration.
              </li>
              <li>
                <img src="assets/images/resources/menu-active-star.png" alt="Awesome Image"/>
                Don't look even slightly.
              </li>
              <li>
                <img src="assets/images/resources/menu-active-star.png" alt="Awesome Image"/>
                If you are going to use a passage.
              </li>
              <li>
                <img src="assets/images/resources/menu-active-star.png" alt="Awesome Image"/>
                You need to sure there embarrassing.
              </li>
            </ul><!-- /.list-unstyled about-four__list -->
          </div><!-- /.about-four__content -->
        </div><!-- /.col-lg-4 -->
        <div class="col-xl-8 col-lg-12">
          <div class="row low-gutters">
            <div class="col-md-6 wow fadeInUp" data-wow-duration="1500ms">
              <div class="about-four__image">
                <img src="assets/images/resources/about-1-1.jpg" class="img-fluid" alt="Awesome Image"/>
                <img src="assets/images/resources/sign.png" class="about-four__sign" alt="Awesome Image"/>
              </div><!-- /.about-four__image -->
            </div><!-- /.col-md-6 -->
            <div class="col-md-6">
              <div class="about-four__box thm-base-bg-2 wow fadeInUp" data-wow-duration="1500ms">
                <div class="about-four__box-top">
                  <i class="potisen-icon-poll"></i>
                  <h4 class="about-four__box-title">Vote Status</h4><!-- /.about-four__box-title -->
                </div><!-- /.about-four__box-top -->
                <p class="about-four__box-text">There are many variations of passages of Lorem Ipsum available, but the
                  majority have suffered alteration in some form, by injected humour or randomised.</p>
                <!-- /.about-four__box-text -->
                <a href="#" class="thm-btn about-four__btn">Learn More</a>
              </div><!-- /.about-four__box -->
            </div><!-- /.col-md-6 -->
          </div><!-- /.row low-gutters -->
        </div><!-- /.col-lg-8 -->
      </div><!-- /.row -->
    </div><!-- /.container -->
  </section>
</template>

<script>
  export default {
    name: "AboutFour"
  }
</script>

<style scoped>

</style>
