<template>
  <section class="thm-gray-bg about-one">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 wow fadeInUp" data-wow-duration="1500ms">
          <img src="/assets/images/resources/gallery-1-1.png" alt="">
        </div><!-- /.col-lg-6 -->
        <div class="col-lg-6 wow fadeInUp" data-wow-duration="1500ms">
          <img src="/assets/images/resources/gallery-1-2.png" alt="Awesome Image" />
        </div><!-- /.col-lg-6 -->
      </div><!-- /.row -->
      <div class="block-title text-center">
        <img src="/assets/images/resources/sec-title-star.png" alt="Awesome Image" class="wow rotateIn" data-wow-duration="1500ms">
        <p class="block-title__tag-line">About Potisen</p>
        <h2 class="block-title__title">Get to Know Potisen</h2><!-- /.block-title__title -->
      </div><!-- /.block-title -->
      <p class="about-one__text text-center m-0">There are many variations of passages of available but the majority have suffered alteration in some <br> form, by injected humou or randomised words. Proin ac lobortis arcu, a vestibulum aug ipsum neque, <br> facilisis vel mollis vitae. Quisque aliquam dictum condim.</p><!-- /.about-one__text -->
    </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "AboutOne"
    }
</script>

<style scoped>

</style>
