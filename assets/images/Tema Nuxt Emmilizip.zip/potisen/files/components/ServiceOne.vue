<template>
  <section class="service-one">
    <div class="container">
      <div class="block-title text-center">
        <img src="/assets/images/resources/sec-title-star.png" alt="Awesome Image" class="wow rotateIn" data-wow-duration="1500ms">
        <p class="block-title__tag-line">What We Can Do Together</p>
        <h2 class="block-title__title">Party Top Priorities</h2><!-- /.block-title__title -->
      </div><!-- /.block-title -->
      <div class="row">
        <div class="col-lg-4 wow fadeInUp" data-wow-duration="1500ms">
          <div class="service-one__single" style="background-image: url(/assets/images/resources/service-1-1.jpg);">
            <div class="service-one__main">
              <div class="service-one__icon">
                <i class="potisen-icon-care"></i>
              </div><!-- /.service-one__icon -->
              <h3 class="service-one__title"><a href="#">Women Rights</a></h3>
            </div><!-- /.service-one__main -->
            <div class="service-one__hover">
              <div class="service-one__icon">
                <i class="potisen-icon-care"></i>
              </div><!-- /.service-one__icon -->
              <h3 class="service-one__title"><a href="#">Women Rights</a></h3>
              <p class="service-one__text">There are many variations of passages of available but the majority have suffered alter randomised words.</p><!-- /.service-one__text -->
            </div><!-- /.service-one__hover -->
          </div><!-- /.service-one__single -->
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4 wow fadeInUp" data-wow-duration="1500ms">
          <div class="service-one__single" style="background-image: url(/assets/images/resources/service-1-2.jpg);">
            <div class="service-one__main">
              <div class="service-one__icon">
                <i class="potisen-icon-medal"></i>
              </div><!-- /.service-one__icon -->
              <h3 class="service-one__title"><a href="#">Civil Rights</a></h3>
            </div><!-- /.service-one__main -->
            <div class="service-one__hover">
              <div class="service-one__icon">
                <i class="potisen-icon-medal"></i>
              </div><!-- /.service-one__icon -->
              <h3 class="service-one__title"><a href="#">Civil Rights</a></h3>
              <p class="service-one__text">There are many variations of passages of available but the majority have suffered alter randomised words.</p><!-- /.service-one__text -->
            </div><!-- /.service-one__hover -->
          </div><!-- /.service-one__single -->
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4 wow fadeInUp" data-wow-duration="1500ms">
          <div class="service-one__single" style="background-image: url(/assets/images/resources/service-1-3.jpg);">
            <div class="service-one__main">
              <div class="service-one__icon">
                <i class="potisen-icon-bid"></i>
              </div><!-- /.service-one__icon -->
              <h3 class="service-one__title"><a href="#">Human Rights</a></h3>
            </div><!-- /.service-one__main -->
            <div class="service-one__hover">
              <div class="service-one__icon">
                <i class="potisen-icon-bid"></i>
              </div><!-- /.service-one__icon -->
              <h3 class="service-one__title"><a href="#">Human Rights</a></h3>
              <p class="service-one__text">There are many variations of passages of available but the majority have suffered alter randomised words.</p><!-- /.service-one__text -->
            </div><!-- /.service-one__hover -->
          </div><!-- /.service-one__single -->
        </div><!-- /.col-lg-4 -->
      </div><!-- /.row -->
    </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "ServiceOne"
    }
</script>

<style scoped>

</style>
