<template>
  <section class="campaing-one">
    <div class="container">
      <div class="block-title text-center">
        <img src="/assets/images/resources/sec-title-star.png" alt="Awesome Image" class="wow rotateIn" data-wow-duration="1500ms">
        <p class="block-title__tag-line">Policy Positions</p>
        <h2 class="block-title__title">Campaign Principles</h2><!-- /.block-title__title -->
      </div><!-- /.block-title -->
      <div class="row">
        <div class="column-5">
          <div class="campaing-one__single">
            <i class="potisen-icon-sprout"></i>
            <h3 class="campaing-one__title"><a href="#">Environment</a></h3><!-- /.campaing-one__title -->
          </div><!-- /.campaing-one__single -->
        </div><!-- /.column-5 -->
        <div class="column-5">
          <div class="campaing-one__single">
            <i class="potisen-icon-care"></i>
            <h3 class="campaing-one__title"><a href="#">Healthcare</a></h3><!-- /.campaing-one__title -->
          </div><!-- /.campaing-one__single -->
        </div><!-- /.column-5 -->
        <div class="column-5">
          <div class="campaing-one__single">
            <i class="potisen-icon-medal"></i>
            <h3 class="campaing-one__title"><a href="#">Tax Returns</a></h3><!-- /.campaing-one__title -->
          </div><!-- /.campaing-one__single -->
        </div><!-- /.column-5 -->
        <div class="column-5">
          <div class="campaing-one__single">
            <i class="potisen-icon-idea"></i>
            <h3 class="campaing-one__title"><a href="#">Economy</a></h3><!-- /.campaing-one__title -->
          </div><!-- /.campaing-one__single -->
        </div><!-- /.column-5 -->
        <div class="column-5">
          <div class="campaing-one__single">
            <i class="potisen-icon-mortarboard"></i>
            <h3 class="campaing-one__title"><a href="#">Education</a></h3><!-- /.campaing-one__title -->
          </div><!-- /.campaing-one__single -->
        </div><!-- /.column-5 -->
      </div><!-- /.row -->
      <p class="campaing-one__more-text text-center">How we can build a better country together!. <nuxt-link to="/donation">Donate or Volunteer.</nuxt-link></p><!-- /.campaing-one__more-text -->
    </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "CampaignOne"
    }
</script>

<style scoped>

</style>
