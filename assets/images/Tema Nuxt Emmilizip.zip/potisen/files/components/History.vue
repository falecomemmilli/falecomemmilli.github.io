<template>
  <section class="history-one">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="history-one__single wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
            <div class="history-one__image">
              <div class="history-one__image-inner"><img alt="" src="/assets/images/resources/history-1-1.jpg"></div><!-- /.history-one__image-inner -->
            </div><!-- /.history-one__image -->
            <div class="history-one__content">
              <h3 class="history-one__title">
                <span class="history-one__year">1996</span>
                Potisen Entered in Politics
              </h3>
              <p class="history-one__text">There are many variations of passages of lorem Ipsum available but the majority have suffered alteration in some form injected which don't look of available but the majority have suffered even slightly believable. Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
            </div><!-- /.history-one__content -->
          </div><!-- /.history-one__single -->
          <div class="history-one__single wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
            <div class="history-one__image">
              <div class="history-one__image-inner"><img alt="" src="/assets/images/resources/history-1-2.jpg"></div><!-- /.history-one__image-inner -->
            </div><!-- /.history-one__image -->
            <div class="history-one__content">
              <h3 class="history-one__title">
                <span class="history-one__year">2004</span>
                Potisen was Growing
              </h3>
              <p class="history-one__text">There are many variations of passages of lorem Ipsum available but the majority have suffered alteration in some form injected which don't look of available but the majority have suffered even slightly believable. Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
            </div><!-- /.history-one__content -->
          </div><!-- /.history-one__single -->
          <div class="history-one__single wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
            <div class="history-one__image">
              <div class="history-one__image-inner"><img alt="" src="/assets/images/resources/history-1-3.jpg"></div><!-- /.history-one__image-inner -->
            </div><!-- /.history-one__image -->
            <div class="history-one__content">
              <h3 class="history-one__title">
                <span class="history-one__year">2011</span>
                We Become Leader in America
              </h3>
              <p class="history-one__text">There are many variations of passages of lorem Ipsum available but the majority have suffered alteration in some form injected which don't look of available but the majority have suffered even slightly believable. Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
            </div><!-- /.history-one__content -->
          </div><!-- /.history-one__single -->
          <div class="history-one__single wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
            <div class="history-one__image">
              <div class="history-one__image-inner"><img alt="" src="/assets/images/resources/history-1-4.jpg"></div><!-- /.history-one__image-inner -->
            </div><!-- /.history-one__image -->
            <div class="history-one__content">
              <h3 class="history-one__title">
                <span class="history-one__year">2019</span>
                Potisen Won the Elections
              </h3>
              <p class="history-one__text">There are many variations of passages of lorem Ipsum available but the majority have suffered alteration in some form injected which don't look of available but the majority have suffered even slightly believable. Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
            </div><!-- /.history-one__content -->
          </div><!-- /.history-one__single -->
        </div><!-- /.col-lg-12 -->
      </div><!-- /.row -->
    </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "History"
    }
</script>

<style scoped>

</style>
