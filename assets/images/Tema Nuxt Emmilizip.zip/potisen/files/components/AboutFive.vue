<template>
  <section class="about-five">
    <div class="container">
      <div class="row">
        <div class="col-xl-6">
          <div class="about-five__image wow fadeInLeft" data-wow-duration="1500ms">
            <img src="/assets/images/resources/about-2-1.png" class="img-fluid" alt="Awesome Image" />
            <img src="/assets/images/resources/sign.png" class="about-five__image-sign" alt="Awesome Image" />
          </div><!-- /.about-five__image -->
        </div><!-- /.col-lg-6 -->
        <div class="col-xl-6">
          <div class="about-five__content">
            <div class="block-title text-left">
              <img src="/assets/images/resources/sec-title-star.png" alt="Awesome Image" class="wow rotateIn" data-wow-duration="1500ms">
              <p class="block-title__tag-line">Join Potisen Now</p>
              <h2 class="block-title__title">Take a Stand for <br> America</h2><!-- /.block-title__title -->
            </div><!-- /.block-title -->
            <p class="about-five__text">There are many variations of passages of available but the majority have suffered alteration in lipsum is simply free text for marker type of some form by injected.</p><!-- /.about-five__text -->
            <div class="about-five__box">
              <div class="about-five__box-image">
                <div class="about-five__box-image-inner">
                  <img src="/assets/images/resources/about-2-2.png" alt="" class="img-fluid" />
                </div><!-- /.about-five__box-image-inner -->
              </div><!-- /.about-five__box-image -->
              <div class="about-five__box-content">
                <h3 class="about-five__box-title">What is Our Economic Plan for this year?</h3><!-- /.about-five__box-title -->
              </div><!-- /.about-five__box-content -->
            </div><!-- /.about-five__box -->
          </div><!-- /.about-five__content -->
        </div><!-- /.col-lg-6 -->
      </div><!-- /.row -->
    </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "AboutFive"
    }
</script>

<style scoped>

</style>
