<template>
  <section class="team-one">
    <div class="container">
      <div class="block-title text-center">
        <img src="/assets/images/resources/sec-title-star.png" alt="Awesome Image" class="wow rotateIn" data-wow-duration="1500ms">
        <p class="block-title__tag-line">Our Party People</p>
        <h2 class="block-title__title">Meet the Team</h2><!-- /.block-title__title -->
      </div><!-- /.block-title -->
      <div class="row">
        <div class="col-lg-4">
          <div class="team-one__single">
            <div class="team-one__image">
              <img src="/assets/images/resources/team-1-1.jpg" alt="Awesome Image" />
            </div><!-- /.team-one__image -->
            <div class="team-one__content">
              <h3 class="team-one__title">Brian Sahm</h3>
              <p class="team-one__designation">Party Leader</p><!-- /.team-one__designation -->
              <div class="team-one__social">
                <a href="#" class="fa fa-twitter"></a>
                <a href="#" class="fa fa-facebook-square"></a>
                <a href="#" class="fa fa-pinterest-p"></a>
                <a href="#" class="fa fa-instagram"></a>
              </div><!-- /.team-one__social -->
            </div><!-- /.team-one__content -->
          </div><!-- /.team-one__single -->
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4">
          <div class="team-one__single">
            <div class="team-one__image">
              <img src="/assets/images/resources/team-1-2.jpg" alt="Awesome Image" />
            </div><!-- /.team-one__image -->
            <div class="team-one__content">
              <h3 class="team-one__title">Mark Ruprecht</h3>
              <p class="team-one__designation">Party Leader</p><!-- /.team-one__designation -->
              <div class="team-one__social">
                <a href="#" class="fa fa-twitter"></a>
                <a href="#" class="fa fa-facebook-square"></a>
                <a href="#" class="fa fa-pinterest-p"></a>
                <a href="#" class="fa fa-instagram"></a>
              </div><!-- /.team-one__social -->
            </div><!-- /.team-one__content -->
          </div><!-- /.team-one__single -->
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4">
          <div class="team-one__single">
            <div class="team-one__image">
              <img src="/assets/images/resources/team-1-3.jpg" alt="Awesome Image" />
            </div><!-- /.team-one__image -->
            <div class="team-one__content">
              <h3 class="team-one__title">Alejandra Bayardo</h3>
              <p class="team-one__designation">Party Leader</p><!-- /.team-one__designation -->
              <div class="team-one__social">
                <a href="#" class="fa fa-twitter"></a>
                <a href="#" class="fa fa-facebook-square"></a>
                <a href="#" class="fa fa-pinterest-p"></a>
                <a href="#" class="fa fa-instagram"></a>
              </div><!-- /.team-one__social -->
            </div><!-- /.team-one__content -->
          </div><!-- /.team-one__single -->
        </div><!-- /.col-lg-4 -->
      </div><!-- /.row -->
    </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "TeamOne"
    }
</script>

<style scoped>

</style>
