<template>
  <div>
    <NavOne/>
    <SliderOne />
    <AboutFour />
    <FunFactOne />
    <AboutThree />
    <CallToActionTwo />
    <CampaignOne />
    <EventOne />
    <CountdownOne />
    <AboutTwo />
    <TestimonialTwo/>
    <SubscribeOne />
    <BlogOne />
    <Brands />
    <SocialShare />
    <Footer />
  </div>
</template>

<script>
  import NavOne from "../components/NavOne";
  import SliderOne from "../components/SliderOne";
  import AboutFour from "../components/AboutFour";
  import FunFactOne from "../components/FunFactOne";
  import CallToActionTwo from "../components/CallToActionTwo";
  import CampaignOne from "../components/CampaignOne";
  import EventOne from "../components/EventOne";
  import CountdownOne from "../components/CountdownOne";
  import AboutTwo from "../components/AboutTwo";
  import TestimonialTwo from "../components/TestimonialTwo";
  import SubscribeOne from "../components/SubscribeOne";
  import BlogOne from "../components/BlogOne";
  import Brands from "../components/Brands";
  import SocialShare from "../components/SocialShare";
  import Footer from "../components/Footer";

  export default {
    components: {
      BlogOne,
      SubscribeOne,
      TestimonialTwo,
      AboutTwo,
      CountdownOne,
      EventOne,
      CallToActionTwo,
      FunFactOne,
      NavOne,
      SliderOne,
      CampaignOne,
      Brands,
      SocialShare,
      Footer,
      AboutFour,
    }
  }
</script>

